<?php
$valor = $_POST["valor_pagar"];
$edad = $_POST["edad"];
$des = $valor*0.2;
$total = $valor - $des;
if //si entra es mayor de edad
($edad <=0){
    die("edad no valido");
}
if($valor<=0)
{
 die("venta no valida");
}
if($edad>60)
{
  echo "Te damos un descuento del 20% <br>".$des;
}
else //es menor de edad
{
    echo  "La venta es de: <br>".$valor;
}

?>