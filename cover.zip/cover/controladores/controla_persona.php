<?php
$nombre = $_POST["nombre"];
$documento = $_POST["docu"];
$edad = $_POST["edad"];
if($edad >= 18)
{
    //echo $edad;
    //Si entra aca es porque es mayor de edad
    echo "tome guaro <br>";
}else{
    echo "eche pa la casa <br>";
//Si entra aca es menor de edad
}
echo $nombre." - ".$documento;

?>