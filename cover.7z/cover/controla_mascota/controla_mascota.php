<?php
$valor = $_POST["Recibe_tu_mascota"];


if($valor>0)
{
  echo "El total de mascotas es ". $valor;
}else{
  echo "Digite una cantidad valida , 0 o menos no es una cantidad valida";
}
?>