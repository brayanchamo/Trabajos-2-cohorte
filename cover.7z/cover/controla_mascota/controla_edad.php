<?php
$edad = $_POST["e-adoptante"];


if($edad>=18)
{
  echo "Felicidades acabas de adoptar una mascota". $edad;
}else{
  echo "Lo sentimos debes traer un mayor de edad para la adopcion";
}
?>